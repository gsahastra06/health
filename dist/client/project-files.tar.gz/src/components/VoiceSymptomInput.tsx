import { useEffect, useRef, useState } from "react";
import { Mic, MicOff, Languages, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { matchSymptomsFromTranscript } from "@/lib/symptom-keywords";
import { SYMPTOMS } from "@/data/diseases";

type Lang = "en-IN" | "te-IN";

// Minimal typing for Web Speech API (not in TS DOM lib)
type SpeechRecognitionLike = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  onresult: ((e: any) => void) | null;
  onerror: ((e: any) => void) | null;
  onend: (() => void) | null;
};

export function VoiceSymptomInput({
  onSymptomsMatched,
}: {
  onSymptomsMatched: (symptomIds: string[]) => void;
}) {
  const [lang, setLang] = useState<Lang>("en-IN");
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [lastMatched, setLastMatched] = useState<string[]>([]);
  const [supported, setSupported] = useState(true);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);

  useEffect(() => {
    const SR =
      (typeof window !== "undefined" &&
        ((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition)) ||
      null;
    if (!SR) {
      setSupported(false);
      return;
    }
    const rec: SpeechRecognitionLike = new SR();
    rec.continuous = true;
    rec.interimResults = true;
    recognitionRef.current = rec;
    return () => {
      try {
        rec.stop();
      } catch {}
    };
  }, []);

  const start = () => {
    const rec = recognitionRef.current;
    if (!rec) return;
    rec.lang = lang;
    setTranscript("");
    setLastMatched([]);

    rec.onresult = (e: any) => {
      let full = "";
      for (let i = 0; i < e.results.length; i++) {
        full += e.results[i][0].transcript + " ";
      }
      setTranscript(full.trim());
      const matched = matchSymptomsFromTranscript(full);
      if (matched.length) {
        setLastMatched(matched);
        onSymptomsMatched(matched);
      }
    };
    rec.onerror = (e: any) => {
      const err = e?.error ?? "unknown";
      if (err === "not-allowed") toast.error("Microphone access denied");
      else if (err !== "no-speech" && err !== "aborted") toast.error("Voice error: " + err);
      setListening(false);
    };
    rec.onend = () => setListening(false);

    try {
      rec.start();
      setListening(true);
    } catch {
      // already started
    }
  };

  const stop = () => {
    recognitionRef.current?.stop();
    setListening(false);
    if (transcript && lastMatched.length === 0) {
      toast.info("No symptoms recognised — try simpler words.");
    } else if (lastMatched.length) {
      toast.success(`Added ${lastMatched.length} symptom${lastMatched.length > 1 ? "s" : ""}`);
    }
  };

  if (!supported) {
    return (
      <div className="rounded-xl border border-dashed border-border p-4 text-sm text-muted-foreground">
        Voice input isn't supported in this browser. Try Chrome on Android or desktop.
      </div>
    );
  }

  const labelFor = (id: string) => SYMPTOMS.find((s) => s.id === id)?.label ?? id;

  return (
    <div className="rounded-xl border border-border bg-accent/30 p-4">
      <div className="flex items-center justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          <Languages className="size-4 text-mint" />
          <div className="inline-flex rounded-md border border-border bg-background p-0.5">
            <button
              type="button"
              onClick={() => !listening && setLang("en-IN")}
              disabled={listening}
              className={`px-2.5 py-1 text-xs rounded ${lang === "en-IN" ? "bg-navy text-primary-foreground" : "text-muted-foreground"}`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => !listening && setLang("te-IN")}
              disabled={listening}
              className={`px-2.5 py-1 text-xs rounded ${lang === "te-IN" ? "bg-navy text-primary-foreground" : "text-muted-foreground"}`}
            >
              తెలుగు
            </button>
          </div>
        </div>
        <Button
          type="button"
          size="sm"
          variant={listening ? "destructive" : "navy"}
          onClick={listening ? stop : start}
          className="gap-2"
        >
          {listening ? (
            <>
              <MicOff className="size-4" /> Stop
            </>
          ) : (
            <>
              <Mic className="size-4" /> Speak
            </>
          )}
        </Button>
      </div>

      {listening && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
          <Loader2 className="size-3 animate-spin" />
          Listening… describe symptoms naturally
        </div>
      )}

      {transcript && (
        <div className="text-sm bg-background rounded-md p-2.5 border border-border mb-2">
          <span className="text-xs uppercase tracking-wide text-muted-foreground block mb-0.5">
            Heard
          </span>
          {transcript}
        </div>
      )}

      {lastMatched.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mt-2">
          {lastMatched.map((id) => (
            <Badge key={id} className="bg-mint text-navy border-0">
              ✓ {labelFor(id)}
            </Badge>
          ))}
        </div>
      )}

      {!listening && !transcript && (
        <p className="text-xs text-muted-foreground">
          Tap <strong>Speak</strong> and describe what the patient is feeling. Matching symptoms
          will be auto-selected below.
        </p>
      )}
    </div>
  );
}
