// Telugu + English keywords mapped to symptom IDs.
// Used to match transcribed voice input against the symptom catalog.
// Telugu words are written in both Telugu script and roman transliteration
// since speech recognition may return either.

export const SYMPTOM_KEYWORDS: Record<string, string[]> = {
  fever: ["fever", "temperature", "జ్వరం", "jwaram", "jvaram", "venta"],
  high_fever: ["high fever", "very high temperature", "ఎక్కువ జ్వరం", "ekkuva jwaram", "tivra jwaram"],
  chills: ["chills", "shivering", "shiver", "చలి", "chali", "vanuku", "వణుకు"],
  fatigue: ["fatigue", "weakness", "tired", "weak", "నీరసం", "neerasam", "balaheenam", "బలహీనత"],
  weight_loss: ["weight loss", "losing weight", "బరువు తగ్గడం", "baruvu taggadam"],
  night_sweats: ["night sweats", "sweating at night", "రాత్రి చెమటలు", "ratri chematalu"],

  cough_dry: ["dry cough", "పొడి దగ్గు", "podi daggu"],
  cough_wet: ["wet cough", "cough with phlegm", "cough with sputum", "కఫం దగ్గు", "kapham daggu"],
  cough_blood: ["coughing blood", "blood in cough", "రక్తం దగ్గు", "raktam daggu"],
  shortness_breath: ["shortness of breath", "breathless", "difficulty breathing", "ఊపిరి ఆడటం లేదు", "upiri adatam ledu", "swasa kashtam"],
  chest_pain: ["chest pain", "ఛాతీ నొప్పి", "chati noppi", "గుండె నొప్పి", "gunde noppi"],
  sore_throat: ["sore throat", "throat pain", "గొంతు నొప్పి", "gontu noppi"],
  runny_nose: ["runny nose", "blocked nose", "cold", "ముక్కు కారడం", "mukku karadam", "jaladosham"],

  diarrhea: ["diarrhea", "loose motion", "loose motions", "విరేచనాలు", "virechanalu", "నీరు విరేచనాలు"],
  bloody_stool: ["blood in stool", "bloody stool", "మలంలో రక్తం", "malamlo raktam"],
  vomiting: ["vomiting", "vomit", "throwing up", "వాంతులు", "vantulu"],
  nausea: ["nausea", "feeling sick", "వికారం", "vikaram"],
  abdominal_pain: ["stomach pain", "abdominal pain", "stomach ache", "కడుపు నొప్పి", "kadupu noppi"],
  loss_appetite: ["loss of appetite", "no appetite", "not eating", "ఆకలి లేదు", "akali ledu"],
  dehydration: ["dehydration", "dehydrated", "నిర్జలీకరణ", "nirjalikarana"],

  headache: ["headache", "head pain", "తలనొప్పి", "talanoppi"],
  severe_headache: ["severe headache", "bad headache", "తీవ్రమైన తలనొప్పి", "tivra talanoppi"],
  body_ache: ["body ache", "body pain", "muscle pain", "ఒళ్ళు నొప్పులు", "ollu noppulu", "శరీర నొప్పి"],
  joint_pain: ["joint pain", "joints hurt", "కీళ్ల నొప్పులు", "keella noppulu"],
  neck_stiffness: ["neck stiffness", "stiff neck", "మెడ బిగుసుకుపోవడం", "meda bigusukupovadam"],
  dizziness: ["dizziness", "dizzy", "giddy", "తల తిరగడం", "tala tiragadam"],

  rash: ["rash", "skin rash", "దద్దుర్లు", "daddurlu"],
  yellow_skin: ["yellow skin", "yellow eyes", "jaundice", "కామెర్లు", "kamerlu", "పచ్చకామెర్లు"],
  pale_skin: ["pale skin", "looking pale", "పాలిపోయిన చర్మం", "palipoyina charmam"],

  high_bp: ["high blood pressure", "high bp", "hypertension", "అధిక రక్తపోటు", "adhika raktapotu", "BP ekkuva"],
  frequent_urination: ["frequent urination", "urinating often", "తరచూ మూత్రవిసర్జన", "tarachu mutravisarjana"],
  excessive_thirst: ["excessive thirst", "very thirsty", "ఎక్కువ దాహం", "ekkuva daham"],
  blurred_vision: ["blurred vision", "blurry vision", "మసక చూపు", "masaka chupu"],

  vaginal_bleeding: ["vaginal bleeding", "bleeding pregnancy", "గర్భస్రావ రక్తస్రావం", "garbha raktasravam"],
  swelling_feet: ["swelling in feet", "swollen face", "swollen legs", "కాళ్లు వాపు", "kallu vapu", "ముఖం వాపు"],
  reduced_fetal_movement: ["reduced fetal movement", "baby not moving", "శిశువు కదలికలు తగ్గాయి", "sisuvu kadalikalu taggayi"],

  anxiety: ["anxiety", "restlessness", "ఆందోళన", "andolana"],
  low_mood: ["low mood", "sadness", "depressed", "విచారం", "vicharam", "దుఃఖం"],
  insomnia: ["insomnia", "trouble sleeping", "can't sleep", "నిద్ర పట్టడం లేదు", "nidra pattadam ledu"],
};

export function matchSymptomsFromTranscript(transcript: string): string[] {
  const text = transcript.toLowerCase();
  const matched = new Set<string>();
  for (const [symptomId, keywords] of Object.entries(SYMPTOM_KEYWORDS)) {
    for (const kw of keywords) {
      if (text.includes(kw.toLowerCase())) {
        matched.add(symptomId);
        break;
      }
    }
  }
  return Array.from(matched);
}
