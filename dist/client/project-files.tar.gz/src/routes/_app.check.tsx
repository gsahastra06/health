import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { z } from "zod";
import { zodValidator } from "@tanstack/zod-adapter";
import { Stethoscope, ArrowRight, AlertTriangle, CheckCircle2, Clock, Video, ArrowLeft, HelpCircle, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { SYMPTOMS, DISEASES, diagnose, URGENCY_META, symptomLabel, type DiagnosisResult } from "@/data/diseases";
import { VoiceSymptomInput } from "@/components/VoiceSymptomInput";

const searchSchema = z.object({
  patientId: z.string().optional(),
});

export const Route = createFileRoute("/_app/check")({
  validateSearch: zodValidator(searchSchema),
  component: CheckPage,
});

type Patient = { id: string; full_name: string; age: number; gender: string };
type Step = "patient" | "complaint" | "primary" | "followup" | "notes" | "results";
type PrimaryAnswer = "yes" | "no";

// High-level chief complaint groups → which symptom categories they pull from.
const COMPLAINTS: { id: string; label: string; emoji: string; categories: string[] }[] = [
  { id: "fever", label: "Fever / chills", emoji: "🌡️", categories: ["General"] },
  { id: "respiratory", label: "Cough / breathing", emoji: "🫁", categories: ["Respiratory"] },
  { id: "digestive", label: "Stomach / digestion", emoji: "🤢", categories: ["Digestive"] },
  { id: "pain", label: "Headache / body pain", emoji: "🤕", categories: ["Pain"] },
  { id: "skin", label: "Skin issues", emoji: "🧴", categories: ["Skin"] },
  { id: "metabolic", label: "Thirst / urination / BP", emoji: "💧", categories: ["Cardio", "Metabolic"] },
  { id: "maternal", label: "Pregnancy concerns", emoji: "🤰", categories: ["Maternal"] },
  { id: "mental", label: "Mood / sleep", emoji: "🧠", categories: ["Mental"] },
];

function CheckPage() {
  const { patientId } = Route.useSearch();
  const navigate = useNavigate();

  const [patients, setPatients] = useState<Patient[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<string | undefined>(patientId);
  const [complaintId, setComplaintId] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [primaryIdx, setPrimaryIdx] = useState(0);
  const [primaryAnswers, setPrimaryAnswers] = useState<Record<string, PrimaryAnswer>>({});
  const [followups, setFollowups] = useState<string[]>([]);
  const [followupIdx, setFollowupIdx] = useState(0);
  const [followupAnswers, setFollowupAnswers] = useState<Record<string, "yes" | "no">>({});
  const [notes, setNotes] = useState("");
  const [step, setStep] = useState<Step>("patient");
  const [results, setResults] = useState<DiagnosisResult[]>([]);
  const [topUrgency, setTopUrgency] = useState<"self_care" | "see_doctor" | "urgent_referral">("self_care");
  const [saving, setSaving] = useState(false);
  const [savedConsultId, setSavedConsultId] = useState<string | null>(null);

  useEffect(() => {
    supabase
      .from("patients")
      .select("id, full_name, age, gender")
      .order("created_at", { ascending: false })
      .then(({ data, error }) => {
        if (error) toast.error(error.message);
        else setPatients(data as Patient[]);
      });
  }, []);

  // Symptoms shown in step "primary" — filtered by chosen complaint categories.
  const primarySymptoms = useMemo(() => {
    if (!complaintId) return [];
    const cats = COMPLAINTS.find((c) => c.id === complaintId)!.categories;
    return SYMPTOMS.filter((s) => cats.includes(s.category));
  }, [complaintId]);

  // All symptoms the worker has explicitly answered "no" to.
  const deniedSymptoms = useMemo(() => {
    const denied = new Set<string>();
    for (const [s, a] of Object.entries(primaryAnswers)) if (a === "no") denied.add(s);
    for (const [s, a] of Object.entries(followupAnswers)) if (a === "no") denied.add(s);
    return Array.from(denied);
  }, [primaryAnswers, followupAnswers]);

  // Live differential — recomputed as confirmed/denied symptoms change.
  const liveDifferential = useMemo(() => {
    if (selected.size === 0) return [];
    return diagnose(Array.from(selected), deniedSymptoms).results.slice(0, 3);
  }, [selected, deniedSymptoms]);

  const answerPrimary = (yes: boolean) => {
    const sym = primarySymptoms[primaryIdx];
    if (!sym) return;
    const newAnswers = { ...primaryAnswers, [sym.id]: (yes ? "yes" : "no") as PrimaryAnswer };
    setPrimaryAnswers(newAnswers);
    if (yes) {
      setSelected((prev) => {
        const next = new Set(prev);
        next.add(sym.id);
        return next;
      });
    }
    if (primaryIdx + 1 < primarySymptoms.length) {
      setPrimaryIdx(primaryIdx + 1);
    } else {
      const confirmed = new Set(selected);
      if (yes) confirmed.add(sym.id);
      if (confirmed.size === 0) {
        toast.error("No symptoms confirmed. Try a different concern.");
        setStep("complaint");
        return;
      }
      const denied = new Set<string>();
      for (const [s, a] of Object.entries(newAnswers)) if (a === "no") denied.add(s);
      const first = pickNextQuestion(confirmed, denied, new Set(primarySymptoms.map((s) => s.id)));
      if (!first) {
        setStep("notes");
        return;
      }
      setFollowups([first]);
      setFollowupIdx(0);
      setStep("followup");
    }
  };

  // Pick the next question with highest expected information gain.
  // Treat the current top candidates' confidences as a probability distribution
  // and choose the unasked symptom that most evenly splits them — i.e. the answer
  // (yes/no) gives us the most signal. Cardinal (high-weight) symptoms get a
  // small tie-breaker bonus so hallmark symptoms surface earlier.
  const pickNextQuestion = (
    confirmed: Set<string>,
    denied: Set<string>,
    alreadyAsked: Set<string>,
  ): string | null => {
    const { results: candidates } = diagnose(Array.from(confirmed), Array.from(denied));
    const top = candidates.slice(0, 6);
    if (top.length < 2) return null;

    // Normalize confidences to a probability distribution over candidates.
    const totalConf = top.reduce((s, c) => s + c.confidence, 0) || 1;
    const probs = top.map((c) => c.confidence / totalConf);
    const baseEntropy = probs.reduce((s, p) => (p > 0 ? s - p * Math.log2(p) : s), 0);

    const pool = new Set<string>();
    for (const c of top) {
      const d = DISEASES.find((x) => x.id === c.diseaseId)!;
      for (const sid of Object.keys(d.symptoms)) {
        if (!confirmed.has(sid) && !denied.has(sid) && !alreadyAsked.has(sid)) {
          pool.add(sid);
        }
      }
    }
    if (pool.size === 0) return null;

    let best: { sid: string; score: number } | null = null;
    for (const sid of pool) {
      // P(yes) = sum of candidate probs whose disease lists this symptom,
      // weighted by the symptom's strength (1-3) for that disease.
      let pYes = 0;
      let avgWeight = 0;
      let cntWith = 0;
      for (let i = 0; i < top.length; i++) {
        const d = DISEASES.find((x) => x.id === top[i].diseaseId)!;
        const w = d.symptoms[sid] ?? 0;
        if (w > 0) {
          pYes += probs[i] * (w / 3); // weight 3 → full prob, weight 1 → 1/3
          avgWeight += w;
          cntWith += 1;
        }
      }
      const pNo = 1 - pYes;
      if (pYes <= 0.02 || pNo <= 0.02) continue; // skip non-discriminating
      avgWeight = cntWith > 0 ? avgWeight / cntWith : 0;

      // Expected entropy after answer ≈ binary entropy of the split.
      // Maximizing information gain == picking the most balanced split.
      const splitEntropy =
        -(pYes * Math.log2(pYes) + pNo * Math.log2(pNo));
      const gain = baseEntropy - (baseEntropy - splitEntropy); // == splitEntropy
      const score = gain + avgWeight * 0.04; // tiny cardinal bonus

      if (!best || score > best.score) best = { sid, score };
    }
    return best?.sid ?? null;
  };


  const MAX_FOLLOWUPS = 6;

  const answerFollowup = (answer: "yes" | "no" | "unsure") => {
    const sid = followups[followupIdx];

    let newConfirmed = selected;
    const newAnswers = { ...followupAnswers };
    if (answer !== "unsure") {
      newAnswers[sid] = answer;
      if (answer === "yes") {
        newConfirmed = new Set(selected);
        newConfirmed.add(sid);
        setSelected(newConfirmed);
      }
    }
    setFollowupAnswers(newAnswers);

    const denied = new Set<string>();
    for (const [s, a] of Object.entries(primaryAnswers)) if (a === "no") denied.add(s);
    for (const [s, a] of Object.entries(newAnswers)) if (a === "no") denied.add(s);
    const asked = new Set<string>(followups);

    const { results } = diagnose(Array.from(newConfirmed), Array.from(denied));
    const leaderClear =
      results.length >= 1 &&
      results[0].confidence >= 75 &&
      (results.length === 1 || results[0].confidence - results[1].confidence >= 20);

    if (followups.length >= MAX_FOLLOWUPS || leaderClear) {
      setStep("notes");
      return;
    }

    const next = pickNextQuestion(newConfirmed, denied, asked);
    if (!next) {
      setStep("notes");
      return;
    }
    setFollowups((prev) => [...prev, next]);
    setFollowupIdx(followupIdx + 1);
  };

  const handleAnalyze = async () => {
    if (!selectedPatient) return toast.error("Select a patient first.");
    if (selected.size === 0) return toast.error("Select at least one symptom.");
    const r = diagnose(Array.from(selected), deniedSymptoms);
    setResults(r.results);
    // Base urgency on the TOP match only — otherwise every fever case ends up
    // "urgent" because malaria/dengue/meningitis are always in the candidate list.
    // Only escalate to the highest urgency if a high-confidence (>=55%) urgent
    // condition is in the top 2.
    let urgency: "self_care" | "see_doctor" | "urgent_referral" = "self_care";
    if (r.results.length > 0) {
      urgency = r.results[0].urgency;
      const rank = { self_care: 0, see_doctor: 1, urgent_referral: 2 } as const;
      for (const cand of r.results.slice(0, 2)) {
        if (cand.confidence >= 55 && rank[cand.urgency] > rank[urgency]) {
          urgency = cand.urgency;
        }
      }
    }
    setTopUrgency(urgency);
    setStep("results");

    setSaving(true);
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) {
      setSaving(false);
      return toast.error("Not signed in");
    }
    const qaTrail = followups.map((sid) => ({
      symptomId: sid,
      question: symptomLabel(sid),
      answer: followupAnswers[sid] ?? "skipped",
    }));
    const primarySymptomIds = Array.from(selected).filter((s) => !(s in followupAnswers));
    const qaBlock = qaTrail.length
      ? `\n\n--- Q&A TRAIL ---\n${qaTrail.map((q, i) => `${i + 1}. Does patient have ${q.question}? → ${q.answer.toUpperCase()}`).join("\n")}`
      : "";
    const primaryBlock = primarySymptomIds.length
      ? `\n\n--- PRIMARY SYMPTOMS REPORTED ---\n${primarySymptomIds.map((s) => `• ${symptomLabel(s)}`).join("\n")}`
      : "";
    const combinedNotes = `${notes.trim()}${primaryBlock}${qaBlock}`.trim() || null;

    const { data, error } = await supabase
      .from("consultations")
      .insert({
        patient_id: selectedPatient,
        asha_id: userData.user.id,
        symptoms: Array.from(selected),
        diagnoses: r.results.map((x) => ({ id: x.diseaseId, name: x.name, confidence: x.confidence, urgency: x.urgency })),
        urgency: r.topUrgency,
        notes: combinedNotes,
      })
      .select("id")
      .single();
    setSaving(false);
    if (error) toast.error("Could not save: " + error.message);
    else if (data) setSavedConsultId(data.id);
  };

  const clearTriageState = () => {
    setComplaintId(null);
    setSelected(new Set());
    setPrimaryIdx(0);
    setPrimaryAnswers({});
    setFollowups([]);
    setFollowupIdx(0);
    setFollowupAnswers({});
    setNotes("");
    setResults([]);
    setSavedConsultId(null);
  };

  const reset = () => {
    clearTriageState();
    setStep("patient");
  };

  // Switching the patient must wipe any in-progress triage data so questions
  // are not driven by the previous patient's symptoms.
  const handlePatientChange = (id: string) => {
    if (id !== selectedPatient) clearTriageState();
    setSelectedPatient(id);
  };

  const back = () => {
    if (step === "complaint") setStep("patient");
    else if (step === "primary") {
      if (primaryIdx > 0) setPrimaryIdx(primaryIdx - 1);
      else setStep("complaint");
    } else if (step === "followup") {
      if (followupIdx > 0) setFollowupIdx(followupIdx - 1);
      else setStep("primary");
    } else if (step === "notes") {
      setStep(followups.length > 0 ? "followup" : "primary");
      if (followups.length > 0) setFollowupIdx(followups.length - 1);
    }
  };

  // ===== Step indicator =====
  const STEPS_ORDER: Step[] = ["patient", "complaint", "primary", "followup", "notes", "results"];
  const currentIdx = STEPS_ORDER.indexOf(step);
  const progressPct = ((currentIdx) / (STEPS_ORDER.length - 1)) * 100;

  return (
    <div className="mx-auto max-w-2xl px-4 py-6 md:py-10">
      <div className="mb-6 animate-slide-up">
        <div className="inline-flex items-center gap-2 rounded-full bg-mint/15 border border-mint/30 px-3 py-1 text-xs font-medium text-navy mb-3">
          <span className="size-1.5 rounded-full bg-mint animate-pulse" />
          AI-assisted triage
        </div>
        <h1 className="text-3xl md:text-4xl font-display font-bold text-navy flex items-center gap-3">
          <span className="size-10 rounded-2xl bg-[var(--gradient-mint)] grid place-items-center shadow-[var(--shadow-glow)]">
            <Stethoscope className="size-5 text-navy" />
          </span>
          Symptom check
        </h1>
        <p className="text-sm text-muted-foreground mt-2 ml-[52px]">
          Answer a few questions to narrow down the most likely condition.
        </p>
        {step !== "results" && (
          <div className="mt-5">
            <div className="flex items-center justify-between text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5 font-semibold">
              <span>Step {currentIdx + 1} of {STEPS_ORDER.length}</span>
              <span>{Math.round(progressPct)}%</span>
            </div>
            <Progress value={progressPct} className="h-1.5" />
          </div>
        )}
      </div>

      {step !== "patient" && step !== "results" && (
        <button onClick={back} className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-navy mb-4 transition-colors group">
          <ArrowLeft className="size-4 group-hover:-translate-x-0.5 transition-transform" /> Back
        </button>
      )}

      {/* STEP 1 — patient */}
      {step === "patient" && (
        <div className="rounded-2xl bg-card border border-border p-6 card-elevated animate-slide-up">
          <Label className="mb-3 block text-base font-display font-semibold text-navy">Who is the patient?</Label>
          {patients.length === 0 ? (
            <div className="text-sm text-muted-foreground p-4 rounded-xl bg-muted/40 border border-dashed border-border">
              No patients yet. <Link to="/patients" className="text-navy font-medium underline underline-offset-2">Add one</Link> to get started.
            </div>
          ) : (
            <>
              <Select value={selectedPatient} onValueChange={handlePatientChange}>
                <SelectTrigger className="h-12 text-base"><SelectValue placeholder="Select patient" /></SelectTrigger>
                <SelectContent>
                  {patients.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.full_name} · {p.age}y · {p.gender}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                variant="navy"
                size="lg"
                className="w-full mt-5 gap-2 h-12"
                disabled={!selectedPatient}
                onClick={() => setStep("complaint")}
              >
                Continue <ArrowRight className="size-4" />
              </Button>
            </>
          )}
        </div>
      )}

      {/* STEP 2 — chief complaint */}
      {step === "complaint" && (
        <div className="animate-slide-up">
          <div className="rounded-2xl bg-card border border-border p-6 card-elevated">
            <h2 className="font-display font-semibold text-navy text-xl mb-1">
              What is the main concern?
            </h2>
            <p className="text-sm text-muted-foreground mb-5">Pick the area that best describes the patient's biggest problem right now.</p>
            <div className="grid grid-cols-2 gap-3">
              {COMPLAINTS.map((c, i) => (
                <button
                  key={c.id}
                  onClick={() => { setComplaintId(c.id); setStep("primary"); }}
                  className="group flex items-center gap-3 rounded-xl border border-border bg-gradient-to-br from-background to-muted/30 hover:from-mint/10 hover:to-mint/5 hover:border-mint hover:shadow-[var(--shadow-soft)] hover:-translate-y-0.5 p-4 text-left transition-all duration-200 animate-slide-up"
                  style={{ animationDelay: `${i * 40}ms` }}
                >
                  <span className="text-3xl group-hover:scale-110 transition-transform">{c.emoji}</span>
                  <span className="text-sm font-semibold text-navy leading-tight">{c.label}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="mt-4">
            <VoiceSymptomInput
              onSymptomsMatched={(ids) => {
                setSelected((prev) => {
                  const next = new Set(prev);
                  ids.forEach((id) => next.add(id));
                  return next;
                });
                if (ids.length > 0) toast.success(`${ids.length} symptom(s) added from voice.`);
              }}
            />
          </div>
        </div>
      )}

      {/* STEP 3 — primary symptoms asked one-by-one as yes/no questions */}
      {step === "primary" && complaintId && primarySymptoms.length > 0 && (
        <div key={primaryIdx} className="rounded-2xl bg-card border border-border p-6 card-elevated animate-slide-up">
          <div className="mb-5">
            <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">
              <span className="flex items-center gap-2"><HelpCircle className="size-4 text-mint" /> Question {primaryIdx + 1} of {primarySymptoms.length}</span>
              <span className="font-mono text-navy">{Math.round(((primaryIdx) / primarySymptoms.length) * 100)}%</span>
            </div>
            <Progress value={((primaryIdx) / primarySymptoms.length) * 100} className="h-1.5" />
          </div>
          <h2 className="font-sans text-sm text-muted-foreground mb-2">
            Does the patient have:
          </h2>
          <p className="text-2xl md:text-3xl font-display font-bold text-navy mb-7 leading-tight">
            {primarySymptoms[primaryIdx].label}?
          </p>
          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" size="lg" className="gap-2 h-14 text-base hover:bg-destructive/5 hover:border-destructive/40 hover:text-destructive transition-colors" onClick={() => answerPrimary(false)}>
              <X className="size-5" /> No
            </Button>
            <Button variant="navy" size="lg" className="gap-2 h-14 text-base shadow-[var(--shadow-soft)]" onClick={() => answerPrimary(true)}>
              <Check className="size-5" /> Yes
            </Button>
          </div>
          {selected.size > 0 && (
            <div className="mt-5 pt-4 border-t border-border">
              <div className="text-xs uppercase tracking-wide text-muted-foreground mb-2">
                Confirmed so far
              </div>
              <div className="flex flex-wrap gap-1.5">
                {Array.from(selected).map((s) => (
                  <Badge key={s} variant="secondary" className="text-xs">{symptomLabel(s)}</Badge>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* STEP 4 — yes/no follow-up clarifying questions */}
      {step === "followup" && followups.length > 0 && (
        <div className="space-y-4">
          {/* Live differential preview */}
          {liveDifferential.length > 0 && (
            <div className="rounded-2xl bg-gradient-to-br from-mint/15 via-mint/5 to-transparent border border-mint/40 p-5 animate-slide-up">
              <div className="flex items-center justify-between mb-3">
                <div className="text-xs uppercase tracking-wider text-navy font-bold flex items-center gap-2">
                  <span className="size-1.5 rounded-full bg-mint animate-pulse" />
                  Most likely so far
                </div>
                <span className="text-[10px] text-muted-foreground font-medium">live</span>
              </div>
              <div className="space-y-3">
                {liveDifferential.map((r, i) => (
                  <div key={r.diseaseId} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className={`font-semibold ${i === 0 ? "text-navy" : "text-muted-foreground"}`}>
                        {i === 0 && "🎯 "}{r.name}
                      </span>
                      <span className="font-mono font-bold text-navy text-sm">{r.confidence}%</span>
                    </div>
                    <Progress value={r.confidence} className="h-2 transition-all duration-500" />
                  </div>
                ))}
              </div>
            </div>
          )}

          <div key={followupIdx} className="rounded-2xl bg-card border border-border p-6 card-elevated animate-slide-up">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-4">
              <HelpCircle className="size-4 text-mint" />
              Question {followupIdx + 1} · narrowing diagnosis
            </div>
            <h2 className="font-sans text-sm text-muted-foreground mb-2">
              Does the patient also have:
            </h2>
            <p className="text-2xl md:text-3xl font-display font-bold text-navy mb-7 leading-tight">
              {symptomLabel(followups[followupIdx])}?
            </p>
            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" size="lg" className="gap-2 h-14 text-base hover:bg-destructive/5 hover:border-destructive/40 hover:text-destructive transition-colors" onClick={() => answerFollowup("no")}>
                <X className="size-5" /> No
              </Button>
              <Button variant="navy" size="lg" className="gap-2 h-14 text-base shadow-[var(--shadow-soft)]" onClick={() => answerFollowup("yes")}>
                <Check className="size-5" /> Yes
              </Button>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="w-full mt-3 text-muted-foreground hover:text-navy"
              onClick={() => answerFollowup("unsure")}
            >
              Not sure / can't tell
            </Button>
            <button
              onClick={() => setStep("notes")}
              className="mt-2 text-xs text-muted-foreground hover:text-navy w-full text-center transition-colors"
            >
              Skip remaining questions →
            </button>
          </div>
        </div>
      )}

      {/* STEP 5 — notes & analyze */}
      {step === "notes" && (
        <div className="space-y-4 animate-slide-up">
          <div className="rounded-2xl bg-card border border-border p-5 card-elevated">
            <Label htmlFor="notes" className="mb-2 block font-display font-semibold text-navy">Field notes (optional)</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Onset, duration, observations…"
              maxLength={500}
              rows={3}
              className="resize-none"
            />
          </div>
          <div className="rounded-2xl bg-gradient-to-br from-mint/10 to-transparent border border-mint/30 p-4">
            <div className="text-xs uppercase tracking-wider text-navy font-bold mb-2.5">
              {selected.size} symptom{selected.size === 1 ? "" : "s"} recorded
            </div>
            <div className="flex flex-wrap gap-1.5">
              {Array.from(selected).map((s) => (
                <Badge key={s} variant="secondary" className="text-xs bg-card border border-border">{symptomLabel(s)}</Badge>
              ))}
            </div>
          </div>
          <Button variant="navy" size="lg" className="w-full gap-2 h-12 shadow-[var(--shadow-glow)] animate-pulse-glow" onClick={handleAnalyze}>
            Analyze symptoms <ArrowRight className="size-4" />
          </Button>
        </div>
      )}

      {/* RESULTS */}
      {step === "results" && (
        <Results
          results={results}
          urgency={topUrgency}
          saving={saving}
          patientId={selectedPatient!}
          consultId={savedConsultId}
          onReset={reset}
          onEscalate={() => navigate({ to: "/consult", search: { patientId: selectedPatient, consultId: savedConsultId ?? undefined } })}
        />
      )}
    </div>
  );
}

function Results({
  results,
  urgency,
  saving,
  patientId,
  consultId,
  onReset,
  onEscalate,
}: {
  results: DiagnosisResult[];
  urgency: "self_care" | "see_doctor" | "urgent_referral";
  saving: boolean;
  patientId: string;
  consultId: string | null;
  onReset: () => void;
  onEscalate: () => void;
}) {
  const meta = URGENCY_META[urgency];
  const Icon = urgency === "urgent_referral" ? AlertTriangle : urgency === "see_doctor" ? Clock : CheckCircle2;
  const toneGradient =
    meta.tone === "destructive" ? "var(--gradient-urgent)"
    : meta.tone === "warning" ? "var(--gradient-warning)"
    : "var(--gradient-success)";

  return (
    <div className="animate-slide-up">
      <button onClick={onReset} className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-navy mb-4 transition-colors group">
        <ArrowLeft className="size-4 group-hover:-translate-x-0.5 transition-transform" /> New check
      </button>

      <div
        className="relative overflow-hidden rounded-3xl p-7 text-white shadow-[var(--shadow-elevated)]"
        style={{ background: toneGradient }}
      >
        <div className="absolute -top-16 -right-16 size-48 rounded-full bg-white/10 blur-2xl" aria-hidden />
        <div className="absolute -bottom-12 -left-12 size-40 rounded-full bg-white/5 blur-2xl" aria-hidden />
        <div className="relative flex items-start gap-4">
          <div className="size-14 rounded-2xl bg-white/20 backdrop-blur grid place-items-center shrink-0">
            <Icon className="size-7" />
          </div>
          <div className="flex-1">
            <div className="text-xs uppercase tracking-wider opacity-90 font-semibold">Recommended action</div>
            <h2 className="text-3xl font-display font-bold mt-1 leading-tight">{meta.label}</h2>
            <p className="mt-2 text-sm opacity-95 leading-relaxed">{meta.description}</p>
          </div>
        </div>
      </div>

      <div className="mt-8 mb-4 flex items-center justify-between">
        <h3 className="font-display font-bold text-navy text-lg">Likely conditions</h3>
        {saving && <span className="text-xs text-muted-foreground flex items-center gap-1.5"><span className="size-1.5 rounded-full bg-mint animate-pulse" />saving…</span>}
        {!saving && consultId && <span className="text-xs text-success font-medium flex items-center gap-1.5"><CheckCircle2 className="size-3.5" /> Saved</span>}
      </div>

      {results.length === 0 ? (
        <div className="text-sm text-muted-foreground p-8 text-center rounded-2xl border-2 border-dashed border-border bg-muted/30">
          Symptoms don't strongly match any condition in the database. Consider direct teleconsult.
        </div>
      ) : (
        <div className="space-y-3">
          {results.map((r, i) => (
            <div
              key={r.diseaseId}
              className={`rounded-2xl bg-card border p-5 transition-all hover:-translate-y-0.5 hover:shadow-[var(--shadow-soft)] animate-slide-up ${i === 0 ? "border-mint/60 ring-2 ring-mint/20" : "border-border"}`}
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <div className="flex items-baseline justify-between gap-3 mb-2.5">
                <div className="flex items-center gap-2 flex-wrap">
                  {i === 0 && <Badge className="bg-[var(--gradient-mint)] text-navy border-0 font-bold shadow-sm">Top match</Badge>}
                  <h4 className="font-display font-bold text-navy text-base">{r.name}</h4>
                </div>
                <span className={`text-lg font-mono font-bold ${i === 0 ? "text-navy" : "text-muted-foreground"}`}>{r.confidence}%</span>
              </div>
              <Progress value={r.confidence} className="h-2 mb-3" />
              <p className="text-sm text-muted-foreground leading-relaxed">{r.description}</p>
              <div className="mt-3 text-xs p-3 rounded-lg bg-muted/50 border border-border">
                <span className="text-muted-foreground font-semibold uppercase tracking-wide">Guidance · </span>
                <span className="text-foreground">{r.guidance}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-8 flex flex-wrap gap-3">
        {urgency === "urgent_referral" && (
          <Button variant="navy" size="lg" className="gap-2 h-12 flex-1 min-w-[180px] shadow-[var(--shadow-soft)] animate-pulse-glow" onClick={onEscalate}>
            <Video className="size-4" /> Escalate to doctor — urgent
          </Button>
        )}
        <Link to="/patients/$patientId" params={{ patientId }}>
          <Button variant="outline" size="lg" className="h-12">View patient</Button>
        </Link>
      </div>
    </div>
  );
}
