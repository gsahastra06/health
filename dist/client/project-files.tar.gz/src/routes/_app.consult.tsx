import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { zodValidator } from "@tanstack/zod-adapter";
import { Video, Stethoscope, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { AgoraVideoCall } from "@/components/AgoraVideoCall";
import { toast } from "sonner";

const searchSchema = z.object({
  patientId: z.string().optional(),
  consultId: z.string().optional(),
});

export const Route = createFileRoute("/_app/consult")({
  validateSearch: zodValidator(searchSchema),
  component: ConsultPage,
});

const DOCTORS = [
  { id: "d1", name: "Dr. Priya Sharma", specialty: "General Physician", lang: "Hindi · English", rating: 4.9, online: true },
  { id: "d2", name: "Dr. Arjun Reddy", specialty: "Pediatrics", lang: "Telugu · Hindi · English", rating: 4.8, online: true },
  { id: "d3", name: "Dr. Meera Nair", specialty: "Obstetrics & Gynae", lang: "Malayalam · English", rating: 4.9, online: true },
  { id: "d4", name: "Dr. Imran Khan", specialty: "Internal Medicine", lang: "Urdu · Hindi · English", rating: 4.7, online: false },
];

type Doctor = typeof DOCTORS[number];

function ConsultPage() {
  const { consultId, patientId } = Route.useSearch();
  const [stage, setStage] = useState<"select" | "waiting" | "incall" | "ended">("select");
  const [doctor, setDoctor] = useState<Doctor | null>(null);
  const [recipientPhone, setRecipientPhone] = useState("");
  // Stable, shareable Agora channel for this consult session.
  const [channel] = useState(
    () => `asha-${consultId ?? patientId ?? "demo"}-${Math.random().toString(36).slice(2, 8)}`
  );
  const shareUrl = typeof window !== "undefined"
    ? `${window.location.origin}/join-call?channel=${encodeURIComponent(channel)}`
    : undefined;

  const copyCallLink = () => {
    const message = `Join the video consultation: ${shareUrl}\nChannel: ${channel}`;
    if (shareUrl) {
      navigator.clipboard?.writeText(message).catch(() => {});
      toast.success("Call link copied. Send it to the phone number on WhatsApp.");
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 md:py-10">
      <div className="mb-6">
        <h1 className="text-2xl md:text-3xl font-display font-bold text-navy flex items-center gap-2">
          <Video className="size-6 text-mint" /> Teleconsultation
        </h1>
        <p className="text-sm text-muted-foreground mt-1">Connect with a doctor for case escalation.</p>
      </div>

      {stage === "select" && (
        <DoctorPicker
          onPick={(d) => {
            setDoctor(d);
            setStage("waiting");
          }}
        />
      )}
      {stage === "waiting" && doctor && (
        <Waiting
          doctor={doctor}
          recipientPhone={recipientPhone}
          onRecipientPhoneChange={setRecipientPhone}
          onConnect={() => {
            copyCallLink();
            setStage("incall");
          }}
          onCancel={() => setStage("select")}
        />
      )}
      {stage === "incall" && doctor && (
        <AgoraVideoCall
          channel={channel}
          doctorName={doctor.name}
          doctorSpecialty={doctor.specialty}
          recipientPhone={recipientPhone}
          shareUrl={shareUrl}
          onEnd={async () => {
            if (consultId) {
              await supabase.from("consultations").update({ escalated: true }).eq("id", consultId);
            }
            setStage("ended");
          }}
        />
      )}
      {stage === "ended" && doctor && <Ended doctor={doctor} onNew={() => setStage("select")} />}
    </div>
  );
}

function DoctorPicker({ onPick }: { onPick: (d: Doctor) => void }) {
  return (
    <div className="grid sm:grid-cols-2 gap-3">
      {DOCTORS.map((d) => (
        <button
          key={d.id}
          onClick={() => d.online && onPick(d)}
          disabled={!d.online}
          className="text-left rounded-2xl bg-card border border-border p-5 hover:border-mint hover:shadow-[var(--shadow-soft)] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <div className="flex items-start justify-between gap-2">
            <Avatar className="size-12">
              <AvatarFallback className="bg-[var(--gradient-mint)] text-navy font-semibold">
                {d.name.split(" ").slice(-1)[0].charAt(0)}
              </AvatarFallback>
            </Avatar>
            <Badge className={d.online ? "bg-success text-success-foreground border-0" : "bg-muted text-muted-foreground border-0"}>
              {d.online ? "● Online" : "○ Offline"}
            </Badge>
          </div>
          <div className="mt-3">
            <div className="font-semibold text-navy">{d.name}</div>
            <div className="text-sm text-muted-foreground">{d.specialty}</div>
            <div className="text-xs text-muted-foreground mt-1">{d.lang}</div>
            <div className="mt-2 inline-flex items-center gap-1 text-xs text-warning-foreground">
              <Star className="size-3 fill-warning text-warning" /> {d.rating}
            </div>
          </div>
        </button>
      ))}
    </div>
  );
}

function Waiting({
  doctor,
  recipientPhone,
  onRecipientPhoneChange,
  onConnect,
  onCancel,
}: {
  doctor: Doctor;
  recipientPhone: string;
  onRecipientPhoneChange: (phone: string) => void;
  onConnect: () => void;
  onCancel: () => void;
}) {

  return (
    <div className="rounded-2xl bg-navy text-primary-foreground p-10 text-center">
      <div className="relative mx-auto size-20 mb-6">
        <div className="absolute inset-0 rounded-full bg-mint/20 animate-ping" />
        <div className="absolute inset-0 rounded-full bg-mint/10 animate-pulse" />
        <div className="relative size-20 rounded-full bg-[var(--gradient-mint)] grid place-items-center text-navy font-display font-bold text-2xl">
          {doctor.name.split(" ").slice(-1)[0].charAt(0)}
        </div>
      </div>
      <h2 className="text-xl font-display font-semibold">Connect to {doctor.name}</h2>
      <p className="mt-2 text-white/70 text-sm">{doctor.specialty}</p>
      <div className="mt-6 mx-auto max-w-sm text-left">
        <Label htmlFor="recipient-phone" className="text-white/80">Recipient phone number</Label>
        <Input
          id="recipient-phone"
          type="tel"
          value={recipientPhone}
          onChange={(event) => onRecipientPhoneChange(event.target.value)}
          placeholder="e.g. 919876543210"
          className="mt-2 bg-white/10 border-white/20 text-white placeholder:text-white/45"
        />
      </div>
      <div className="mt-6 flex flex-wrap justify-center gap-3">
        <Button variant="outline" className="bg-white/5 border-white/20 text-white hover:bg-white/10 hover:text-white" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="secondary" disabled={recipientPhone.replace(/\D/g, "").length < 10} onClick={onConnect}>
          Start video call
        </Button>
      </div>
    </div>
  );
}

function Ended({ doctor, onNew }: { doctor: Doctor; onNew: () => void }) {
  return (
    <div className="rounded-2xl bg-card border border-border p-10 text-center">
      <div className="size-14 mx-auto rounded-full bg-success grid place-items-center text-success-foreground mb-4">
        <Stethoscope className="size-6" />
      </div>
      <h2 className="text-xl font-display font-bold text-navy">Consultation ended</h2>
      <p className="mt-2 text-sm text-muted-foreground">
        Your case with {doctor.name} has been logged. Continue with the recommended care plan.
      </p>
      <div className="mt-6 flex flex-wrap gap-2 justify-center">
        <Button variant="navy" onClick={onNew}>New consultation</Button>
      </div>
    </div>
  );
}
