import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Users, Stethoscope, Video, ArrowRight, Activity, AlertTriangle, Clock, CheckCircle2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_app/home")({
  component: HomePage,
  head: () => ({ meta: [{ title: "Home — ASHA Assistant" }] }),
});

type Stats = {
  patients: number;
  consultsThisWeek: number;
  urgentOpen: number;
};

type RecentConsult = {
  id: string;
  created_at: string;
  urgency: string;
  patient: { full_name: string } | null;
};

function HomePage() {
  const { user } = useAuth();
  const [stats, setStats] = useState<Stats>({ patients: 0, consultsThisWeek: 0, urgentOpen: 0 });
  const [recent, setRecent] = useState<RecentConsult[]>([]);
  const [loading, setLoading] = useState(true);
  const [greeting, setGreeting] = useState("Welcome");

  useEffect(() => {
    const h = new Date().getHours();
    setGreeting(h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening");
  }, []);

  useEffect(() => {
    const load = async () => {
      const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();

      const [{ count: pCount }, { count: cCount }, { count: uCount }, { data: rData }] = await Promise.all([
        supabase.from("patients").select("id", { count: "exact", head: true }),
        supabase.from("consultations").select("id", { count: "exact", head: true }).gte("created_at", weekAgo),
        supabase.from("consultations").select("id", { count: "exact", head: true }).eq("urgency", "urgent_referral"),
        supabase
          .from("consultations")
          .select("id, created_at, urgency, patient:patients(full_name)")
          .order("created_at", { ascending: false })
          .limit(5),
      ]);

      setStats({
        patients: pCount ?? 0,
        consultsThisWeek: cCount ?? 0,
        urgentOpen: uCount ?? 0,
      });
      setRecent((rData as unknown as RecentConsult[]) ?? []);
      setLoading(false);
    };
    load();
  }, []);

  const displayName = (user?.user_metadata?.full_name as string | undefined) ?? user?.email?.split("@")[0] ?? "ASHA worker";

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 md:py-10">
      {/* Hero greeting */}
      <div className="relative overflow-hidden rounded-3xl p-7 md:p-9 text-primary-foreground shadow-[var(--shadow-elevated)] mb-8 animate-slide-up"
        style={{ background: "var(--gradient-hero)" }}>
        <div className="absolute -top-20 -right-20 size-64 rounded-full bg-mint/30 blur-3xl" aria-hidden />
        <div className="absolute -bottom-16 -left-16 size-52 rounded-full bg-white/10 blur-2xl" aria-hidden />
        <div className="relative">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-medium backdrop-blur">
            <Sparkles className="size-3" />
            {greeting}
          </span>
          <h1 className="mt-4 text-3xl md:text-4xl font-display font-bold leading-tight">
            Hello, {displayName}
          </h1>
          <p className="mt-2 text-white/80 text-sm md:text-base max-w-xl">
            Ready to help your community today? Start a new symptom check or review your patient register.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/check">
              <Button variant="hero" size="lg" className="gap-2">
                <Stethoscope className="size-4" /> New symptom check
              </Button>
            </Link>
            <Link to="/patients">
              <Button variant="outline" size="lg" className="bg-white/5 border-white/20 text-white hover:bg-white/10 hover:text-white gap-2">
                <Users className="size-4" /> View patients
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <StatCard label="Registered patients" value={stats.patients} icon={Users} loading={loading} />
        <StatCard label="Consults this week" value={stats.consultsThisWeek} icon={Activity} loading={loading} />
        <StatCard label="Urgent referrals" value={stats.urgentOpen} icon={AlertTriangle} loading={loading} accent={stats.urgentOpen > 0} />
      </div>

      {/* Quick actions */}
      <div className="grid md:grid-cols-3 gap-4 mb-8">
        <QuickAction
          to="/check"
          icon={Stethoscope}
          title="Start a check"
          desc="Smart Q&A driven triage with confidence-rated diagnosis."
        />
        <QuickAction
          to="/patients"
          icon={Users}
          title="Patient register"
          desc="Add, search and review your village patients."
        />
        <QuickAction
          to="/consult"
          icon={Video}
          title="Teleconsult"
          desc="Escalate complex cases to a doctor over video."
        />
      </div>

      {/* Recent activity */}
      <div className="rounded-2xl bg-card border border-border p-5 md:p-6 card-elevated">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-bold text-navy text-lg">Recent consultations</h2>
          <Link to="/patients" className="text-xs text-muted-foreground hover:text-navy font-medium">View all →</Link>
        </div>
        {loading ? (
          <div className="text-sm text-muted-foreground py-8 text-center">Loading…</div>
        ) : recent.length === 0 ? (
          <div className="text-sm text-muted-foreground py-10 text-center rounded-xl bg-muted/30 border border-dashed border-border">
            No consultations yet. <Link to="/check" className="text-navy font-medium underline underline-offset-2">Start your first check</Link>.
          </div>
        ) : (
          <ul className="divide-y divide-border">
            {recent.map((c) => (
              <li key={c.id} className="py-3 flex items-center justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="font-medium text-navy truncate">{c.patient?.full_name ?? "Unknown patient"}</div>
                  <div className="text-xs text-muted-foreground">{new Date(c.created_at).toLocaleString()}</div>
                </div>
                <UrgencyBadge urgency={c.urgency} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function StatCard({ label, value, icon: Icon, loading, accent }: { label: string; value: number; icon: typeof Users; loading: boolean; accent?: boolean }) {
  return (
    <div className={`rounded-2xl bg-card border p-5 card-elevated transition ${accent ? "border-destructive/40 ring-1 ring-destructive/20" : "border-border"}`}>
      <div className="flex items-center justify-between mb-3">
        <div className={`size-10 rounded-xl grid place-items-center ${accent ? "bg-destructive/10 text-destructive" : "bg-mint/15 text-navy"}`}>
          <Icon className="size-5" />
        </div>
      </div>
      <div className="text-3xl font-display font-bold text-navy tabular-nums">
        {loading ? "—" : value}
      </div>
      <div className="text-xs text-muted-foreground mt-1 uppercase tracking-wide font-semibold">{label}</div>
    </div>
  );
}

function QuickAction({ to, icon: Icon, title, desc }: { to: "/check" | "/patients" | "/consult"; icon: typeof Stethoscope; title: string; desc: string }) {
  return (
    <Link to={to} className="group block rounded-2xl bg-card border border-border p-5 card-elevated hover:-translate-y-0.5 hover:border-mint hover:shadow-[var(--shadow-soft)] transition-all">
      <div className="flex items-start gap-4">
        <div className="size-11 rounded-xl bg-[var(--gradient-mint)] grid place-items-center text-navy shrink-0">
          <Icon className="size-5" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="font-display font-semibold text-navy">{title}</h3>
          <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{desc}</p>
        </div>
        <ArrowRight className="size-4 text-muted-foreground group-hover:text-navy group-hover:translate-x-0.5 transition-all" />
      </div>
    </Link>
  );
}

function UrgencyBadge({ urgency }: { urgency: string }) {
  if (urgency === "urgent_referral")
    return <Badge className="bg-destructive/10 text-destructive border border-destructive/30 gap-1"><AlertTriangle className="size-3" />Urgent</Badge>;
  if (urgency === "see_doctor")
    return <Badge className="bg-amber-500/10 text-amber-700 border border-amber-500/30 gap-1"><Clock className="size-3" />See doctor</Badge>;
  return <Badge className="bg-mint/15 text-navy border border-mint/40 gap-1"><CheckCircle2 className="size-3" />Self-care</Badge>;
}
