import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Phone, MapPin, Stethoscope, Video, Trash2, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { URGENCY_META, symptomLabel, type Urgency } from "@/data/diseases";

export const Route = createFileRoute("/_app/patients/$patientId")({
  component: PatientDetail,
});

type Patient = {
  id: string;
  full_name: string;
  age: number;
  gender: string;
  village: string | null;
  phone: string | null;
  notes: string | null;
};

type Consultation = {
  id: string;
  symptoms: string[];
  diagnoses: { name: string; confidence: number }[];
  urgency: Urgency;
  notes: string | null;
  escalated: boolean;
  created_at: string;
};

function PatientDetail() {
  const { patientId } = Route.useParams();
  const navigate = useNavigate();
  const [patient, setPatient] = useState<Patient | null>(null);
  const [consults, setConsults] = useState<Consultation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const [{ data: p, error: pErr }, { data: c, error: cErr }] = await Promise.all([
        supabase.from("patients").select("*").eq("id", patientId).maybeSingle(),
        supabase
          .from("consultations")
          .select("id, symptoms, diagnoses, urgency, notes, escalated, created_at")
          .eq("patient_id", patientId)
          .order("created_at", { ascending: false }),
      ]);
      if (pErr) toast.error(pErr.message);
      if (cErr) toast.error(cErr.message);
      setPatient(p as Patient | null);
      setConsults((c ?? []) as unknown as Consultation[]);
      setLoading(false);
    };
    load();
  }, [patientId]);

  const handleDelete = async () => {
    const { error } = await supabase.from("patients").delete().eq("id", patientId);
    if (error) return toast.error(error.message);
    toast.success("Patient removed.");
    navigate({ to: "/patients" });
  };

  if (loading) return <div className="p-8 text-center text-muted-foreground">Loading…</div>;
  if (!patient) return <div className="p-8 text-center text-muted-foreground">Patient not found.</div>;

  return (
    <div className="mx-auto max-w-4xl px-4 py-6 md:py-10">
      <Link to="/patients" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="size-4" /> All patients
      </Link>

      <div className="rounded-2xl bg-card border border-border p-6 shadow-[var(--shadow-soft)]">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-4">
            <div className="size-14 rounded-full bg-[var(--gradient-mint)] text-navy grid place-items-center font-display font-bold text-xl">
              {patient.full_name.charAt(0).toUpperCase()}
            </div>
            <div>
              <h1 className="text-2xl font-display font-bold text-navy">{patient.full_name}</h1>
              <div className="flex flex-wrap gap-3 mt-1 text-sm text-muted-foreground">
                <span>{patient.age} years</span>
                <span>·</span>
                <span className="capitalize">{patient.gender}</span>
                {patient.village && (
                  <><span>·</span><span className="inline-flex items-center gap-1"><MapPin className="size-3" /> {patient.village}</span></>
                )}
                {patient.phone && (
                  <><span>·</span><span className="inline-flex items-center gap-1"><Phone className="size-3" /> {patient.phone}</span></>
                )}
              </div>
            </div>
          </div>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Delete patient">
                <Trash2 className="size-4 text-destructive" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Remove patient?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete {patient.full_name} and all consultation history.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>

        <div className="mt-5 flex flex-wrap gap-2">
          <Link to="/check" search={{ patientId: patient.id }}>
            <Button variant="navy" className="gap-2"><Stethoscope className="size-4" /> New symptom check</Button>
          </Link>
          <Link to="/consult" search={{ patientId: patient.id }}>
            <Button variant="outline" className="gap-2"><Video className="size-4" /> Teleconsult</Button>
          </Link>
        </div>
      </div>

      <h2 className="mt-10 mb-4 text-lg font-display font-semibold text-navy flex items-center gap-2">
        <Calendar className="size-4 text-mint" />
        Consultation history
        <span className="text-xs font-normal text-muted-foreground">({consults.length})</span>
      </h2>

      {consults.length === 0 ? (
        <div className="text-center py-12 rounded-2xl border border-dashed text-sm text-muted-foreground">
          No consultations yet. Start a new symptom check to build history.
        </div>
      ) : (
        <div className="space-y-3">
          {consults.map((c) => (
            <ConsultationCard key={c.id} c={c} />
          ))}
        </div>
      )}
    </div>
  );
}

function ConsultationCard({ c }: { c: Consultation }) {
  const meta = URGENCY_META[c.urgency];
  const date = new Date(c.created_at).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });

  const toneClass =
    meta.tone === "destructive"
      ? "bg-destructive text-destructive-foreground"
      : meta.tone === "warning"
        ? "bg-warning text-warning-foreground"
        : "bg-success text-success-foreground";

  return (
    <div className="rounded-xl bg-card border border-border p-4">
      <div className="flex items-center justify-between gap-2 mb-3">
        <div className="text-xs text-muted-foreground">{date}</div>
        <Badge className={`${toneClass} border-0`}>{meta.label}</Badge>
      </div>

      {c.diagnoses.length > 0 && (
        <div className="mb-3">
          <div className="text-xs uppercase tracking-wide text-muted-foreground mb-1.5">Top suggestion</div>
          <div className="font-semibold text-navy">
            {c.diagnoses[0]?.name}{" "}
            <span className="text-sm font-normal text-muted-foreground">
              · {c.diagnoses[0]?.confidence}% match
            </span>
          </div>
        </div>
      )}

      <div className="text-xs text-muted-foreground mb-1">Symptoms reported</div>
      <div className="flex flex-wrap gap-1.5">
        {c.symptoms.map((s) => (
          <Badge key={s} variant="secondary" className="font-normal">{symptomLabel(s)}</Badge>
        ))}
      </div>

      {c.notes && (
        <div className="mt-3 text-sm text-foreground/80 italic">"{c.notes}"</div>
      )}

      {c.escalated && (
        <div className="mt-3 inline-flex items-center gap-1 text-xs text-mint font-medium">
          <Video className="size-3" /> Escalated to teleconsult
        </div>
      )}
    </div>
  );
}
