import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Plus, Search, ChevronRight, UserPlus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/patients")({
  component: PatientsPage,
});

type Patient = {
  id: string;
  full_name: string;
  age: number;
  gender: "male" | "female" | "other";
  village: string | null;
  phone: string | null;
  created_at: string;
};

function PatientsPage() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("patients")
      .select("id, full_name, age, gender, village, phone, created_at")
      .order("created_at", { ascending: false });
    if (error) toast.error(error.message);
    else setPatients(data as Patient[]);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = patients.filter(
    (p) =>
      p.full_name.toLowerCase().includes(q.toLowerCase()) ||
      (p.village ?? "").toLowerCase().includes(q.toLowerCase()),
  );

  return (
    <div className="mx-auto max-w-4xl px-4 py-6 md:py-10">
      <div className="flex items-center justify-between gap-3 mb-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-display font-bold text-navy">Patients</h1>
          <p className="text-sm text-muted-foreground mt-1">Your private register.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button variant="navy" className="gap-2">
              <Plus className="size-4" /> <span className="hidden sm:inline">New patient</span>
            </Button>
          </DialogTrigger>
          <NewPatientDialog
            onCreated={() => {
              setOpen(false);
              load();
            }}
          />
        </Dialog>
      </div>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
        <Input
          placeholder="Search by name or village…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="pl-9"
        />
        {q && (
          <button
            onClick={() => setQ("")}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            aria-label="Clear"
          >
            <X className="size-4" />
          </button>
        )}
      </div>

      {loading ? (
        <div className="text-center py-12 text-muted-foreground text-sm">Loading…</div>
      ) : filtered.length === 0 ? (
        <EmptyState onAdd={() => setOpen(true)} hasQuery={q.length > 0} />
      ) : (
        <div className="space-y-2">
          {filtered.map((p) => (
            <Link
              key={p.id}
              to="/patients/$patientId"
              params={{ patientId: p.id }}
              className="group flex items-center justify-between gap-3 rounded-xl bg-card border border-border p-4 hover:border-mint hover:shadow-[var(--shadow-soft)] transition-all"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="size-10 rounded-full bg-accent text-navy grid place-items-center font-semibold shrink-0">
                  {p.full_name.charAt(0).toUpperCase()}
                </div>
                <div className="min-w-0">
                  <div className="font-semibold text-navy truncate">{p.full_name}</div>
                  <div className="text-xs text-muted-foreground">
                    {p.age}y · {p.gender}
                    {p.village && ` · ${p.village}`}
                  </div>
                </div>
              </div>
              <ChevronRight className="size-5 text-muted-foreground group-hover:text-primary shrink-0" />
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

function EmptyState({ onAdd, hasQuery }: { onAdd: () => void; hasQuery: boolean }) {
  return (
    <div className="text-center py-16 rounded-2xl border border-dashed border-border">
      <div className="size-12 rounded-full bg-accent grid place-items-center mx-auto mb-4 text-navy">
        <UserPlus className="size-5" />
      </div>
      <h3 className="font-display font-semibold text-navy">
        {hasQuery ? "No matches" : "No patients yet"}
      </h3>
      <p className="text-sm text-muted-foreground mt-1 mb-4">
        {hasQuery ? "Try a different search." : "Add your first patient to begin triage."}
      </p>
      {!hasQuery && (
        <Button variant="navy" onClick={onAdd}>
          <Plus className="size-4" /> Add patient
        </Button>
      )}
    </div>
  );
}

function NewPatientDialog({ onCreated }: { onCreated: () => void }) {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState<"male" | "female" | "other">("female");
  const [village, setVillage] = useState("");
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const ageNum = parseInt(age, 10);
    if (!name.trim()) return toast.error("Name is required.");
    if (Number.isNaN(ageNum) || ageNum < 0 || ageNum > 130) return toast.error("Enter a valid age.");
    setLoading(true);
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) return toast.error("Not signed in");
    const { data, error } = await supabase
      .from("patients")
      .insert({
        asha_id: userData.user.id,
        full_name: name.trim(),
        age: ageNum,
        gender,
        village: village.trim() || null,
        phone: phone.trim() || null,
      })
      .select("id")
      .single();
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Patient added.");
    onCreated();
    if (data) navigate({ to: "/patients/$patientId", params: { patientId: data.id } });
  };

  return (
    <DialogContent className="sm:max-w-md">
      <DialogHeader>
        <DialogTitle>New patient</DialogTitle>
      </DialogHeader>
      <form onSubmit={submit} className="space-y-3">
        <div>
          <Label htmlFor="np-name">Full name</Label>
          <Input id="np-name" required value={name} onChange={(e) => setName(e.target.value)} maxLength={100} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="np-age">Age</Label>
            <Input id="np-age" type="number" required value={age} onChange={(e) => setAge(e.target.value)} min={0} max={130} />
          </div>
          <div>
            <Label>Gender</Label>
            <Select value={gender} onValueChange={(v) => setGender(v as typeof gender)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="female">Female</SelectItem>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div>
          <Label htmlFor="np-village">Village</Label>
          <Input id="np-village" value={village} onChange={(e) => setVillage(e.target.value)} maxLength={80} />
        </div>
        <div>
          <Label htmlFor="np-phone">Phone</Label>
          <Input id="np-phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} maxLength={20} />
        </div>
        <Button type="submit" variant="navy" className="w-full" disabled={loading}>
          {loading ? "Saving…" : "Save patient"}
        </Button>
      </form>
    </DialogContent>
  );
}

void Textarea;
