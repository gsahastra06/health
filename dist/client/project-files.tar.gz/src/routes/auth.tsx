import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Activity, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  component: AuthPage,
  head: () => ({
    meta: [{ title: "Sign in — ASHA Assistant" }],
  }),
});

function AuthPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  // Sign in
  const [siEmail, setSiEmail] = useState("");
  const [siPwd, setSiPwd] = useState("");

  // Sign up
  const [suName, setSuName] = useState("");
  const [suAshaId, setSuAshaId] = useState("");
  const [suRegion, setSuRegion] = useState("");
  const [suEmail, setSuEmail] = useState("");
  const [suPwd, setSuPwd] = useState("");

  const handleSignIn = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email: siEmail, password: siPwd });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Welcome back!");
    navigate({ to: "/home" });
  };

  const handleSignUp = async (e: FormEvent) => {
    e.preventDefault();
    if (suPwd.length < 6) return toast.error("Password must be at least 6 characters.");
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email: suEmail,
      password: suPwd,
      options: {
        emailRedirectTo: `${window.location.origin}/home`,
        data: { full_name: suName, asha_id: suAshaId, region: suRegion },
      },
    });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Account created. You're signed in.");
    navigate({ to: "/home" });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[var(--gradient-hero)]">
      <header className="px-4 py-4">
        <Link to="/" className="inline-flex items-center gap-2 text-primary-foreground/80 hover:text-primary-foreground text-sm">
          <ArrowLeft className="size-4" /> Back
        </Link>
      </header>

      <div className="flex-1 grid place-items-center px-4 py-8">
        <div className="w-full max-w-md">
          <div className="flex items-center justify-center gap-2 mb-6 text-primary-foreground">
            <span className="size-9 rounded-lg bg-mint grid place-items-center text-navy">
              <Activity className="size-5" />
            </span>
            <span className="font-display font-bold text-xl">ASHA Assistant</span>
          </div>

          <div className="bg-card rounded-2xl shadow-[var(--shadow-glow)] p-6 border border-border">
            <Tabs defaultValue="signin" className="w-full">
              <TabsList className="grid grid-cols-2 w-full mb-6">
                <TabsTrigger value="signin">Sign in</TabsTrigger>
                <TabsTrigger value="signup">Create account</TabsTrigger>
              </TabsList>

              <TabsContent value="signin">
                <form onSubmit={handleSignIn} className="space-y-4">
                  <div>
                    <Label htmlFor="si-email">Email</Label>
                    <Input id="si-email" type="email" required value={siEmail} onChange={(e) => setSiEmail(e.target.value)} autoComplete="email" />
                  </div>
                  <div>
                    <Label htmlFor="si-pwd">Password</Label>
                    <Input id="si-pwd" type="password" required value={siPwd} onChange={(e) => setSiPwd(e.target.value)} autoComplete="current-password" />
                  </div>
                  <Button type="submit" variant="navy" className="w-full" disabled={loading}>
                    {loading ? "Signing in…" : "Sign in"}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup">
                <form onSubmit={handleSignUp} className="space-y-3">
                  <div>
                    <Label htmlFor="su-name">Full name</Label>
                    <Input id="su-name" required value={suName} onChange={(e) => setSuName(e.target.value)} maxLength={100} />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label htmlFor="su-asha">ASHA ID</Label>
                      <Input id="su-asha" value={suAshaId} onChange={(e) => setSuAshaId(e.target.value)} maxLength={40} />
                    </div>
                    <div>
                      <Label htmlFor="su-region">Region / village</Label>
                      <Input id="su-region" value={suRegion} onChange={(e) => setSuRegion(e.target.value)} maxLength={80} />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="su-email">Email</Label>
                    <Input id="su-email" type="email" required value={suEmail} onChange={(e) => setSuEmail(e.target.value)} autoComplete="email" />
                  </div>
                  <div>
                    <Label htmlFor="su-pwd">Password (min 6)</Label>
                    <Input id="su-pwd" type="password" required value={suPwd} onChange={(e) => setSuPwd(e.target.value)} autoComplete="new-password" minLength={6} />
                  </div>
                  <Button type="submit" variant="navy" className="w-full" disabled={loading}>
                    {loading ? "Creating account…" : "Create account"}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </div>

          <p className="mt-4 text-center text-xs text-primary-foreground/70">
            By continuing you agree this tool is for triage support only.
          </p>
        </div>
      </div>
    </div>
  );
}
