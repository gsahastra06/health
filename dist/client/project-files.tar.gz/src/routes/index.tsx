import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { Activity, Stethoscope, Video, ShieldCheck, Users, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (data.session) throw redirect({ to: "/home" });
  },
  component: Landing,
  head: () => ({
    meta: [
      { title: "ASHA Assistant — Triage Tool for ASHA Workers" },
      { name: "description", content: "Symptom-based triage and teleconsultation built for India's ASHA frontline workers." },
    ],
  }),
});

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="mx-auto max-w-6xl px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 font-display font-bold text-navy">
            <span className="size-8 rounded-lg bg-[var(--gradient-hero)] grid place-items-center text-primary-foreground">
              <Activity className="size-4" />
            </span>
            ASHA Assistant
          </div>
          <Link to="/auth">
            <Button variant="ghost" size="sm">Sign in</Button>
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div
          className="absolute inset-0 -z-10"
          style={{ background: "var(--gradient-hero)" }}
          aria-hidden
        />
        <div
          className="absolute -top-32 -right-32 size-[500px] rounded-full opacity-30 blur-3xl -z-10"
          style={{ background: "var(--mint)" }}
          aria-hidden
        />

        <div className="mx-auto max-w-6xl px-4 py-20 md:py-28 text-primary-foreground">
          <div className="max-w-3xl">
            <span className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-medium backdrop-blur">
              <span className="size-1.5 rounded-full bg-mint" />
              Built for India's ASHA workers
            </span>
            <h1 className="mt-6 text-4xl md:text-6xl font-display font-bold leading-[1.05]">
              Triage faster.<br />
              Refer smarter.
            </h1>
            <p className="mt-6 text-lg md:text-xl text-white/80 max-w-2xl">
              A pocket triage assistant for frontline health workers. Capture symptoms,
              get evidence-based suggestions, and escalate to a doctor — all in one app.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <Link to="/auth">
                <Button variant="hero" size="lg" className="gap-2">
                  Get started <ArrowRight className="size-4" />
                </Button>
              </Link>
              <a href="#how" className="inline-flex">
                <Button variant="outline" size="lg" className="bg-white/5 border-white/20 text-white hover:bg-white/10 hover:text-white">
                  How it works
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="how" className="mx-auto max-w-6xl px-4 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-display font-bold text-navy">Designed for the field</h2>
          <p className="mt-3 text-muted-foreground max-w-2xl mx-auto">
            Three tools that work even on low bandwidth — wherever your patients are.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              icon: Users,
              title: "Patient register",
              body: "Maintain a private register of patients in your village. History travels with each patient across visits.",
            },
            {
              icon: Stethoscope,
              title: "Symptom triage",
              body: "Multi-select symptoms. Get the top likely conditions with confidence scores and urgency level.",
            },
            {
              icon: Video,
              title: "Teleconsult escalation",
              body: "When a case needs a doctor, escalate to a live video consultation in one tap.",
            },
          ].map((f) => (
            <div
              key={f.title}
              className="p-6 rounded-2xl bg-card border border-border shadow-[var(--shadow-soft)] hover:shadow-lg transition-shadow"
            >
              <div className="size-11 rounded-xl bg-accent grid place-items-center text-navy mb-4">
                <f.icon className="size-5" />
              </div>
              <h3 className="font-display font-semibold text-lg text-navy">{f.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{f.body}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 p-8 md:p-12 rounded-3xl bg-navy text-primary-foreground flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="max-w-xl">
            <div className="flex items-center gap-2 text-mint text-sm font-medium">
              <ShieldCheck className="size-4" />
              Private & secure
            </div>
            <h3 className="mt-2 text-2xl md:text-3xl font-display font-bold">
              Patient data stays with you
            </h3>
            <p className="mt-3 text-white/70">
              Each ASHA worker only sees their own patient register. Powered by row-level security on Lovable Cloud.
            </p>
          </div>
          <Link to="/auth">
            <Button variant="hero" size="lg">Create your account</Button>
          </Link>
        </div>
      </section>

      <footer className="border-t border-border py-8 text-center text-xs text-muted-foreground">
        ASHA Assistant — a triage tool. Not a substitute for clinical judgement.
      </footer>
    </div>
  );
}
