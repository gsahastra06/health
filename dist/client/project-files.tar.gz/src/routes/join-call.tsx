import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { zodValidator } from "@tanstack/zod-adapter";
import { Video } from "lucide-react";
import { AgoraVideoCall } from "@/components/AgoraVideoCall";
import { Button } from "@/components/ui/button";

const searchSchema = z.object({
  channel: z.string().optional(),
});

export const Route = createFileRoute("/join-call")({
  validateSearch: zodValidator(searchSchema),
  component: JoinCallPage,
});

function JoinCallPage() {
  const { channel } = Route.useSearch();
  const [started, setStarted] = useState(false);
  const [ended, setEnded] = useState(false);

  return (
    <main className="min-h-screen bg-background px-4 py-6 md:py-10">
      <div className="mx-auto max-w-5xl">
        <div className="mb-6">
          <h1 className="text-2xl md:text-3xl font-display font-bold text-navy flex items-center gap-2">
            <Video className="size-6 text-mint" /> Video consultation
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Join the live consultation from this device.</p>
        </div>

        {!channel && (
          <div className="rounded-2xl bg-card border border-border p-8 text-center">
            <h2 className="font-display font-bold text-navy text-xl">Call link is missing</h2>
            <p className="mt-2 text-sm text-muted-foreground">Ask the ASHA worker to share the video call link again.</p>
          </div>
        )}

        {channel && !started && !ended && (
          <div className="rounded-2xl bg-card border border-border p-8 text-center">
            <div className="size-16 mx-auto rounded-full bg-[var(--gradient-mint)] grid place-items-center text-navy mb-4">
              <Video className="size-7" />
            </div>
            <h2 className="font-display font-bold text-navy text-xl">Ready to join?</h2>
            <p className="mt-2 text-sm text-muted-foreground">Allow camera and microphone permissions when prompted.</p>
            <Button variant="navy" size="lg" className="mt-6 gap-2" onClick={() => setStarted(true)}>
              <Video className="size-4" /> Join video call
            </Button>
          </div>
        )}

        {channel && started && !ended && (
          <AgoraVideoCall
            channel={channel}
            doctorName="ASHA consultation"
            doctorSpecialty="Live video call"
            onEnd={() => {
              setStarted(false);
              setEnded(true);
            }}
          />
        )}

        {ended && (
          <div className="rounded-2xl bg-card border border-border p-8 text-center">
            <h2 className="font-display font-bold text-navy text-xl">Call ended</h2>
            <p className="mt-2 text-sm text-muted-foreground">You can close this page now.</p>
            <Link to="/">
              <Button variant="outline" className="mt-6">Go home</Button>
            </Link>
          </div>
        )}
      </div>
    </main>
  );
}
